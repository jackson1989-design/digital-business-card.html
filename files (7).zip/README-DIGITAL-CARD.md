# Latimore Life & Legacy LLC - Digital Business Card Suite

## Overview
This suite provides multiple digital business card solutions for Jackson M. Latimore Sr. and Latimore Life & Legacy LLC, designed for various use cases from standalone pages to embeddable widgets.

## Files Included

### 1. digital-business-card.html
**Purpose:** Full-featured standalone digital business card page
**Features:**
- Professional animated design matching brand colors (navy & gold)
- Responsive layout for all devices
- Interactive contact buttons (phone, email, website)
- Social sharing buttons (LinkedIn, Email, WhatsApp, Copy Link)
- Downloadable vCard with one click
- Heartbeat graphic representing #TheBeatGoesOn branding

**Use Cases:**
- Primary landing page for digital business card
- Link from email signatures
- Social media profile links
- QR code destination

**Deployment:**
- Upload to: `/latimore-life-legacy-site/card.html` or `/latimore-life-legacy-site/contact.html`
- Access via: `https://jackson1989-design.github.io/latimore-life-legacy-site/card.html`

### 2. Jackson_Latimore_Contact.vcf
**Purpose:** Standard vCard file for direct contact import
**Features:**
- Contains all contact information
- Compatible with all major contact management systems
- Includes professional notes and business categories

**Use Cases:**
- Email attachments
- Direct download links
- File sharing platforms

**Deployment:**
- Upload to: `/latimore-life-legacy-site/assets/Jackson_Latimore_Contact.vcf`
- Provide download link on website

### 3. card-widget.html
**Purpose:** Compact embeddable business card widget
**Features:**
- Smaller footprint for sidebar or footer placement
- Self-contained styling
- Quick contact access
- Save to contacts functionality

**Use Cases:**
- Website sidebar widget
- Footer contact card
- Blog post author bio
- Email newsletter signature block

**Integration Example:**
```html
<iframe src="https://jackson1989-design.github.io/latimore-life-legacy-site/widget.html" 
        width="100%" 
        height="450" 
        frameborder="0"
        style="max-width: 350px; border-radius: 15px;">
</iframe>
```

### 4. qr-card.html
**Purpose:** QR code landing page with automatic QR generation
**Features:**
- Auto-generates QR code pointing to main website
- Mobile-optimized quick actions
- Contact information grid
- Professional presentation for scanning from printed materials

**Use Cases:**
- Destination page for printed QR codes
- Trade show materials
- Business cards with QR codes
- Brochures and flyers

**Deployment:**
- Upload to: `/latimore-life-legacy-site/qr.html`
- Generate QR code pointing to this page for printed materials

## Brand Colors Reference
```css
--navy: #1a2b4a
--gold: #c9a961
--light-gold: #e8d4a0
--white: #ffffff
```

## Implementation Recommendations

### Website Integration Plan

1. **Homepage:**
   - Add "Get My Card" button in header navigation
   - Link to: `card.html`

2. **Contact Page:**
   - Embed `card-widget.html` as interactive contact card
   - Include direct download link to `.vcf` file

3. **About Page:**
   - Feature QR code section linking to `qr-card.html`
   - Include "Connect With Me" section

4. **Footer:**
   - Quick embed of compact widget
   - "Add to Contacts" call-to-action

### Email Signature Integration
```html
<a href="https://jackson1989-design.github.io/latimore-life-legacy-site/card.html" 
   style="display: inline-block; background: #1a2b4a; color: white; padding: 10px 20px; 
          text-decoration: none; border-radius: 5px; font-weight: 600;">
   📇 View My Digital Card
</a>
```

### Social Media Bio Links
- LinkedIn: Add `card.html` as featured link
- Instagram Bio: Use shortened URL to `card.html`
- Facebook About: Link to `card.html`
- Twitter/X Bio: Include shortened link

### Printed Materials Integration
1. Generate high-resolution QR code pointing to `qr-card.html`
2. Add to:
   - Business cards
   - Brochures
   - Flyers
   - Presentations
   - Proposals

## vCard Best Practices

The vCard file includes:
- Full name with proper formatting
- Professional title and organization
- Primary contact methods
- Website URL
- Professional note with services offered
- Business categories for proper filing

**Distribution Methods:**
1. Direct download link on website
2. Email attachment with proposals
3. Shared via messaging apps
4. Included in digital press kits

## Mobile Optimization

All files are fully responsive and mobile-optimized:
- Touch-friendly buttons (minimum 44px tap targets)
- Readable text sizes (minimum 14px)
- Proper viewport settings
- Fast loading times
- One-tap actions (call, email, save)

## Accessibility Features

- Semantic HTML structure
- Proper ARIA labels where needed
- High contrast ratios (navy on white, gold accents)
- Keyboard navigation support
- Screen reader friendly

## Analytics Tracking (Optional)

To track digital card usage, add Google Analytics or similar:

```html
<!-- Add before </head> in each HTML file -->
<script async src="https://www.googletagmanager.com/gtag/js?id=YOUR-GA-ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'YOUR-GA-ID');
</script>
```

Track events:
- vCard downloads
- Contact button clicks
- Social shares
- Page visits

## Browser Compatibility

All files tested and compatible with:
- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## File Size & Performance

- digital-business-card.html: ~15KB
- card-widget.html: ~8KB
- qr-card.html: ~12KB + QR library (~40KB)
- Jackson_Latimore_Contact.vcf: <1KB

All files load in under 1 second on 3G connections.

## Security Considerations

- No external form submissions
- No collection of user data
- All actions client-side only
- HTTPS recommended for deployment
- No tracking cookies (unless analytics added)

## Future Enhancements

Potential additions:
1. Calendar booking integration
2. Live chat widget
3. Testimonials carousel
4. Service request form
5. Newsletter signup
6. Social media feed integration
7. Video introduction
8. Virtual meeting scheduler

## Support & Updates

For technical support or custom modifications:
- Email: Jackson1989@latimorelegacy.com
- Website: https://jackson1989-design.github.io/latimore-life-legacy-site

## License

© 2025 Latimore Life & Legacy LLC. All rights reserved.

---

**#TheBeatGoesOn - Protecting Today. Securing Tomorrow.**
